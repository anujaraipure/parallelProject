package com.cg.eis.DAO;

import java.io.*;
import java.time.LocalDate;
import java.util.Map;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.Transaction;
import com.cg.eis.bean.Wallet;

public class AccountDAO implements DAO {


	public void create(Account a) {
		
		//
		
		accounts.put(a.getAcId(),a);
		Wallet w=new Wallet();
		w.setWalletBalance(0);
		w.setAcId(a.getAcId());
		wallets.put(a.getAcId(), w);
		System.out.println("Account created successfully!\nYour Account ID is: "+ a.getAcId());
		Transaction t=new Transaction(a.getAcId(), a.getBalance(), w.getWalletBalance(),String.valueOf(LocalDate.now()), "Account Created", a.getBalance());
		transactions.add(t);
	}
	
	public Map<String,Account> show(){
		
		return accounts;
	}
	
	
	public double showAccountBalance(String acId) {
		Account account=getAccount(acId);
		
		return account.getBalance();
	}

	public double depositToAccount(Account account, double amount) {
		account.setBalance(account.getBalance()+amount);
		double bal=account.getBalance();
		Wallet wallet=getWallet(account.getAcId());
		
		Transaction t=new Transaction(account.getAcId(), account.getBalance(), wallet.getWalletBalance(),String.valueOf(LocalDate.now()), "Deposited to account",amount);
		transactions.add(t);
		
		return bal;
	}
	
	public double walletToWallet(Wallet wallet,Wallet receiverWallet, double amount) {
		double bal;
		wallet.setWalletBalance(wallet.getWalletBalance()-amount);
		receiverWallet.setWalletBalance(receiverWallet.getWalletBalance()+amount);
		bal=wallet.getWalletBalance();
		
		Account recAcc=accounts.get(receiverWallet.getAcId());
		Transaction t1=new Transaction(recAcc.getAcId(), recAcc.getBalance(), receiverWallet.getWalletBalance(),String.valueOf(LocalDate.now()), "received in wallet ",amount);
		transactions.add(t1);
		
		Account acc=accounts.get(wallet.getAcId());
		Transaction t=new Transaction(acc.getAcId(), acc.getBalance(), wallet.getWalletBalance(),String.valueOf(LocalDate.now()), "Withdrawn form wallet ",amount);
		transactions.add(t);
		
		
		
		return bal;
	}

	
	public void bankToWallet(Account account,Wallet wallet, double amount) {
	
		account.setBalance(account.getBalance()-amount);
		wallet.setWalletBalance(wallet.getWalletBalance()+amount);
		System.out.println("Fund Transfer Completed Successfully!");
		System.out.println("Wallet Balance: "+wallet.getWalletBalance());
		Transaction t=new Transaction(account.getAcId(), account.getBalance(), wallet.getWalletBalance(),String.valueOf(LocalDate.now()), "Added to wallet ",amount);
		transactions.add(t);
		
	}
	
	public void printTrans(String acId)throws Exception {
		ObjectOutputStream out=new ObjectOutputStream(new  FileOutputStream("a"+acId+".txt"));
		for(Transaction transaction:transactions) {
			if(transaction.getCustId().equals(acId)) 
				System.out.println(transaction);
			out.writeObject(transaction);
		}
		
		
		out.close();
	}

	public Account getAccount(String acId) {
		Account account= accounts.get(acId);
		return account;
	}

	public Wallet getWallet(String acId) {
		Wallet wallet=wallets.get(acId);
		return wallet;
	}

	public Transaction getTransaction(String acId) {
		Transaction transaction=null;
		for(Transaction i:transactions) {
			
			if(i.getCustId().equals(acId))
				System.out.println(i);
		}
		return transaction;
	}

	public Account logIn(String acId, String password) {
			if(accounts.get(acId)!=null) 
				if(accounts.get(acId).getPassword().equals(password)) {
					return accounts.get(acId);
					}
				
			return null;
	}

	public double showWalletBalance(String acId) {
		// TODO Auto-generated method stub
		Wallet wallet=getWallet(acId);
		return wallet.getWalletBalance();
	}
	

}
