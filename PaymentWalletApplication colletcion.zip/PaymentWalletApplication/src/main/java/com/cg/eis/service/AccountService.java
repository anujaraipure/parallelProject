package com.cg.eis.service;

import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import com.cg.eis.DAO.AccountDAO;
import com.cg.eis.bean.Account;
import com.cg.eis.bean.Transaction;
import com.cg.eis.bean.Wallet;
import com.cg.eis.exception.PWAException;

public class AccountService implements Service{

	AccountDAO dao=new AccountDAO();

	
	public void create(Account a) {
	
			dao.create(a);
		
	}

	
	public Account logIn(String acId, String password) {
		
			return dao.logIn(acId,password);
		
	}
	public Map<String, Account> show() {
		
		return dao.show();
	}

	public void walletToAccount(String acId, double amount) {
		Wallet w=getWallet(acId);
		if(w!=null) {
			if(w.getWalletBalance()>=amount) {
				w.setWalletBalance(w.getWalletBalance()-amount);
				System.out.println("Account Balance: "+dao.depositToAccount(getAccount(acId),amount));
				System.out.println("Wallet Balance: "+w.getWalletBalance());
			}
			else
				System.out.println("You dont have enough balance.");
		}
		else {
			System.out.println("Invalid Account Number.");
		}
	
	}
	
	public void depositToAccount(String acId, double amount) {
		
		Account a=getAccount(acId);
		if(a!=null) 
			System.out.println("Updated Balance: "+dao.depositToAccount(a,amount));	
		else 
			System.out.println("Invalid Account Number.");
	}

	public void walletToWallet(String acId,String receiverId, double amount) {
		Wallet w=getWallet(acId);
		Wallet rw=getWallet(receiverId);
		if(rw!=null) {
			if(w!=null) 
				if(w.getWalletBalance()>amount) 
					System.out.println("Wallet Balance: "+dao.walletToWallet(w,rw,amount));
				else 
					System.out.println("You dont have enough balance. \n(Deposit money into your wallet to perform this action)");
			else 
				System.out.println("Incorrect Account ID.");
		}
		else System.out.println("Incorrect Receiver Account Number");
	}

	public void bankToWallet(String acId, double amount) {
		Account a=getAccount(acId);
		Wallet w=getWallet(acId);
		if(a.getBalance()<amount)
			System.out.println("You dont have enough balance.");
		else
			dao.bankToWallet(a, w, amount);
	}

	public void printTrans(String acId)throws Exception {

		dao.printTrans(acId);
	}
	public double showAccountBalance(String acId) {
		
		return dao.showAccountBalance(acId);
	}

	public Account getAccount(String acId) {
		
		return dao.getAccount(acId);
	}

	public Wallet getWallet(String acId) {
		
		return dao.getWallet(acId);
	}

	public Transaction getTransaction(String acId) {
		
		return dao.getTransaction(acId);
	}

	public double showWalletBalance(String acId) {

		return dao.showWalletBalance(acId);
	}

	@Override
	public boolean validateName(String name) throws PWAException {
		boolean valid=true;
		Pattern p=Pattern.compile("^[a-zA-Z ]*$");
		Matcher m=p.matcher(name);
		
			if(!m.matches()) {
				throw new PWAException("Name Should Contain Only Characters. (Reenter the name)");
			}
		return valid;
	}

	@Override
	public boolean validateAmount(Double amount) throws PWAException {
		boolean valid=true;
		if(amount<1000) {
			throw new PWAException("Amount Should Be More 1000 or More. (Reenter amount)");
		}
		return valid;
	}

	@Override
	public boolean validateContact(String contact) throws PWAException {
		boolean valid=true;
		Pattern p=Pattern.compile("[7-9]{1}[0-9]{9}");
		Matcher m=p.matcher(contact);


		if(!m.matches()) {
			throw new PWAException("Invalid Contact Number. (Reenter contact)");
		}
		return valid;
	}

	@Override
	public boolean validatePassword(String password) throws PWAException {
		boolean valid=true;
		Pattern p=Pattern.compile("[0-9A-Za-z]{6,}");
		Matcher m=p.matcher(password);


		if(!m.matches()) {
			throw new PWAException("Invalid Password. (Reenter password with minimum length 6)");
		}
		return valid;
	}

	
}
