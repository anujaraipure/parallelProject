package com.cg.eis.DAO;

import java.util.*;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.Transaction;
import com.cg.eis.bean.Wallet;

public interface DAO {

	Map<String,Account> accounts=new HashMap<String,Account>();
	Map<String,Wallet> wallets=new HashMap<String,Wallet>();
	List<Transaction> transactions=new ArrayList<Transaction>();
	
	double showAccountBalance(String acId);
	double showWalletBalance(String acId);
	
	void create(Account a);
	Map<String,Account> show();
	double depositToAccount(Account account, double amount);
	double walletToWallet(Wallet wallet,Wallet receiverWallet,  double amount);
	void bankToWallet(Account account, Wallet wallet, double amount);
	void printTrans(String acId)throws Exception;
	
	Account getAccount(String acId);
	Wallet getWallet(String acId);
	Transaction getTransaction(String acId);
	Account logIn(String acId,String password);
	
}
