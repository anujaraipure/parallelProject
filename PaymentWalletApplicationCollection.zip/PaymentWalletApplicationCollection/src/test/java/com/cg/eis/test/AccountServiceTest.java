package com.cg.eis.test;


import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import org.junit.Test;

import com.cg.eis.DAO.AccountDAO;
import com.cg.eis.DAO.DAO;
public class AccountServiceTest {

	DAO dao=new AccountDAO();
	@Test
	public void testCreate() {
		System.out.println("hello");
	}

	@Test
	public void testLogInFake() {
		assertNull(dao.logIn("089", "123456"));
	}
	
	/*@Test
	public void testLogInReal() {
		assertNotNull(dao.logIn("4089", "123456"));
	}

	@Test
	public void testShow() {
		fail("Not yet implemented");
	}

	@Test
	public void testDepositToAccountFromWallet() {
		fail("Not yet implemented");
	}

	@Test
	public void testDepositToAccount() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdrawFromWallet() {
		fail("Not yet implemented");
	}

	@Test
	public void testDepositToWallet() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTrans() {
		fail("Not yet implemented");
	}

	@Test
	public void testShowAccountBalance() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAccount() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetWallet() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetTransaction() {
		fail("Not yet implemented");
	}

	@Test
	public void testShowWalletBalance() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateName() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateAmount() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateContact() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidatePassword() {
		fail("Not yet implemented");
	}*/

}
