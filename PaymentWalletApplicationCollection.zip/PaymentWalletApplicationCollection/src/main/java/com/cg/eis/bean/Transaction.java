package com.cg.eis.bean;

import java.io.Serializable;

public class Transaction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double  balance, walletBalance, amount;
	private String custId,date, operation;
	
	
	
	
	public Transaction(String custId, double balance, double walletBalance, String date,
			String operation,double amount) {
		super();
		this.balance = balance;
		this.walletBalance = walletBalance;
		this.setAmount(amount);
		this.custId = custId;
		this.date = date;
		this.operation = operation;
	}


	public Transaction() {}
	

	public double getWalletBalance() {
		return walletBalance;
	}



	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}



	public String getCustId() {
		return custId;
	}
	
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public String getDate() {
		return date;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	
	public String getOperation() {
		return operation;
	}
	
	public void setOperation(String operation) {
		this.operation = operation;
	}



	@Override
	public String toString() {
		return "Transaction [balance=" + balance + ", walletBalance=" + walletBalance + ", amount=" + amount
				+ ", custId=" + custId + ", date=" + date + ", operation=" + operation + "]";
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	
}
