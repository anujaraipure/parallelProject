package com.cg.eis.service;

import java.util.Map;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.Transaction;
import com.cg.eis.bean.Wallet;
import com.cg.eis.exception.PWAException;

public interface Service {

	
	double showAccountBalance(String acId);
	double showWalletBalance(String acId);
	
	void create(Account a);
	Map<String,Account> show();
	void depositToAccount(String acId, double amount);
	void walletToWallet(String acId,String receiverId, double amount);
	void bankToWallet(String acId, double amount);
	void walletToAccount(String acId, double amount);
	void printTrans(String acId)throws Exception;
	
	Account getAccount(String acId);
	Wallet getWallet(String acId);
	Transaction getTransaction(String acId);
	Account logIn(String acId, String password);
	
	boolean validateName(String name) throws PWAException ;
	boolean validatePassword(String password) throws PWAException;
	boolean validateContact(String contact) throws PWAException ;
	boolean validateAmount(Double amount) throws PWAException;

}
