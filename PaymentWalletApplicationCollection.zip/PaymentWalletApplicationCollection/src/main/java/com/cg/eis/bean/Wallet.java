package com.cg.eis.bean;

public class Wallet{
	
	private String acId;
	private double walletBalance;

	public String getAcId() {
		return acId;
	}

	public void setAcId(String acId) {
		this.acId = acId;
	}

	

	public double getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}

	@Override
	public String toString() {
		return "Wallet [acId=" + acId + ", walletBalance=" + walletBalance + "]";
	}
	
	
}

