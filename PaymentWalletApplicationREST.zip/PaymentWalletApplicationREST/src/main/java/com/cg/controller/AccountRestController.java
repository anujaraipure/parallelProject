package com.cg.controller;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.AccountRest;
import com.cg.service.AccountRestService;
import com.cg.service.IAccountRestService;

@RestController
public class AccountRestController {
	@Autowired
	 IAccountRestService accountRestService;
	

	AccountRest accountRest;
	
	@PostMapping("/create")
	public AccountRest createAccount(@RequestBody AccountRest accountRest) {
		
		return accountRestService.createAccount(accountRest);
	}
	
	@GetMapping("/getall")
	public Iterable<AccountRest> getAll(){
		return accountRestService.getAll();
	}
	
	@GetMapping("/getaccount/{id}")
	public Optional<AccountRest> getAccount(@PathVariable int id){
		
		return accountRestService.getAccount(id);
	}
	
	@GetMapping("/showbalance/{id}")
	public Double show(@PathVariable int id ) {
		
		return accountRestService.showBalance(id);
	}
	
	@PostMapping("/deposit/{id}/{amount}")
	public String deposit(@PathVariable int id,@PathVariable BigDecimal amount) {
		
		accountRestService.depositAmount(id, amount);
		return "Successfull Transaction";
	}
	
	@PostMapping("/withdraw/{id}/{amount}")
	public String withdraw(@PathVariable int id ,@PathVariable BigDecimal amount) {
		
		System.out.println(id+"--"+amount.doubleValue());
		accountRestService.withdrawAmount(id, amount);
		return "Successfull Transaction";
	}
	
	@PostMapping("/fundtransfer/{id}/{id2}/{amount}")
	public String fundT(@PathVariable int id,@PathVariable int id2,@PathVariable BigDecimal amount) {
		
		accountRestService.fundTransfer(id, id2, amount);
		return "Fund Transfer Completed";
	}
	

}
