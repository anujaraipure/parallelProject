package com.cg.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class AccountRest{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int acId;
	private String contact;
	private String name;
	@OneToOne(cascade = CascadeType.ALL) 
	@JoinColumn(name="walletId")
	private Wallet wallet;
	
	public AccountRest() {
		super();
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public int getAcId() {
		return acId;
	}
	public void setCid(int acId) {
		this.acId = acId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	public AccountRest(String contact, String name, Wallet wallet) {
		super();
		this.contact = contact;
		this.name = name;
		this.wallet = wallet;
	}
	

}
