package com.cg.service;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.AccountRest;
import com.cg.beans.Wallet;
import com.cg.dao.AccountRestRepository;

@Service
public class AccountRestService implements IAccountRestService {


	@Autowired
	AccountRestRepository accountRestRepository;

	Wallet wallet;

	AccountRest accountRest;


	@Override
	public AccountRest createAccount(AccountRest accountRest) {

		return accountRestRepository.save(accountRest);
	}

	@Override
	public double showBalance(int id) {
		return accountRestRepository.findById(id).get().getWallet().getBalance();
	}

	@Override
	public boolean fundTransfer(int id1 , int id2 , BigDecimal amount) {
		System.out.println(id1+" "+id2);
		AccountRest sourceMobile=accountRestRepository.findById(id1).get();
		System.out.println("Source"+sourceMobile);
		AccountRest targetMobile=accountRestRepository.findById(id2).get();
		System.out.println("Target"+targetMobile);
		if(sourceMobile.getWallet().getBalance()<amount.doubleValue()) {
			return false;
		}else {
			Wallet targetWallet=targetMobile.getWallet();
			double targetBalance=targetWallet.getBalance();
			targetBalance=targetWallet.getBalance()+amount.doubleValue();
			targetWallet.setBalance(targetBalance);
			targetMobile.setWallet(targetWallet);

			Wallet sourceWallet=sourceMobile.getWallet();
			double sourcebalance=sourceWallet.getBalance();
			sourcebalance=sourceWallet.getBalance()-amount.doubleValue();
			sourceWallet.setBalance(sourcebalance);
			sourceMobile.setWallet(sourceWallet);
			accountRestRepository.save(sourceMobile);
			accountRestRepository.save(targetMobile);

			return true;	
		}
	}

	@Override
	public boolean depositAmount(int id , BigDecimal amount) {
		accountRest=accountRestRepository.findById(id).get();
		double balance = accountRest.getWallet().getBalance() +amount.doubleValue();
		wallet=accountRest.getWallet();
		wallet.setBalance(balance);
		accountRest.setWallet(wallet);
		accountRestRepository.save(accountRest);
		return true;
	}

	@Override
	public boolean withdrawAmount( int id, BigDecimal amount) {
		accountRest=accountRestRepository.findById(id).get();
		if(accountRest.getWallet().getBalance()<amount.doubleValue()) {
			return false;	
		}else {
			double balance=accountRest.getWallet().getBalance()-amount.doubleValue();
			wallet=accountRest.getWallet();
			wallet.setBalance(balance);
			accountRest.setWallet(wallet);
			accountRestRepository.save(accountRest);
			return true;

		}
	}

	public String validateNum(int id) {
		String str;
		accountRest= accountRestRepository.findById(id).get();
		if(accountRest!=null) {
			str="Mobileno exists";
		}else {
			str="new user";
		}
		return str;
	}

	public Optional<AccountRest> getAccount(int id ) {
		// TODO Auto-generated method stub
		return accountRestRepository.findById(id);
	}

	@Override
	public Iterable<AccountRest> getAll() {
		// TODO Auto-generated method stub
		return accountRestRepository.findAll();
	}

}
