package com.cg.service;

import java.math.BigDecimal;
import java.util.Optional;

import com.cg.beans.AccountRest;

public interface IAccountRestService {
	public AccountRest createAccount(AccountRest accountRest);

	public Optional<AccountRest> getAccount(int contact);
	double showBalance(int id);
	boolean fundTransfer(int id, int id2, BigDecimal amount);
	boolean depositAmount(int id, BigDecimal amount);
	boolean withdrawAmount(int id, BigDecimal amount);
	String validateNum(int id);

	public Iterable<AccountRest> getAll();
	

}
