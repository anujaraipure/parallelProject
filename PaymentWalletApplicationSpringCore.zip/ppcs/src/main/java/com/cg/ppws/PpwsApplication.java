package com.cg.ppws;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import com.cg.ppws.bean.CSAccount;
import com.cg.ppws.bean.CSTransaction;
import com.cg.ppws.controller.HomeController;
import com.cg.ppws.exception.PWAException;
import com.cg.ppws.service.CSAccountService;

@SpringBootApplication
/* @EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class}) */
public class PpwsApplication extends SpringBootServletInitializer implements CommandLineRunner {

	@Autowired
	CSAccountService servAccount;
	
	
	public SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(PpwsApplication.class);

	}

	public static void main(String[] args) {

		SpringApplication.run(PpwsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		CSAccount a;
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		boolean logoutFlag = false;
		String choice = null;
		System.out.print(
				"\n---------------------------------------------------------------\n1.CREATE ACCOUNT\t2.SIGN IN\t3.SHOW ALL\t4.EXIT"
						+ "\n---------------------------------------------------------------\n\nEnter the choice: ");
		choice = sc.next();
		String name = "", contact = "", password = "";
		Double amount = 0d;

		while (true) {

			switch (choice) {

			case "1":/// create

				a = new CSAccount();
a.setId(1);
				System.out.print("Enter Name:");
				name = sc1.nextLine();
				a.setName(name);

				System.out.print("Contact Number:");
				contact = sc.next();
				a.setContact(contact);

				System.out.print("Password: ");
				password = sc.next();
				a.setPassword(password);

				System.out.print("Balance: ");
				amount = Double.parseDouble(sc.next());
				a.setBalance(amount);

				a.setDateCreated(Date.valueOf(LocalDate.now()));

				a.setWallet(0d);
			/*	private int id;
				
				private String name;
				private String contact;
				private Date dateCreated;
				private Double Balance;
				private Double wallet;
				private String password;*/
				servAccount.addAccount(a);

				break;

			case "2":
				logoutFlag = false;
				System.out.print("Account Number: ");
				int acId = sc.nextInt();
				System.out.print("Password: ");
				String p = sc.next();
				
				boolean account = servAccount.validateLogin(acId,p);

				if (account) {
					CSAccount acc = servAccount.getAccount(acId);
					System.out.println(
							"\n\n-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-*\n\t\t\t\tWELCOME "
									+ acc.getName());

					boolean flag = true;
					while (flag) {
						if (!logoutFlag) {
							System.out.println(
									"------------------------------------MENU--------------------------------------\n1.Show Balance\t\t2.Deposit in bank account\t3.Add money to wallet\n4.Pay From wallet\t5.Transfer back from wallet\t6.Print Transaction\n7.Logout\n------------------------------------------------------------------------------\nEnter Your Choice: ");
							choice = sc.next();
						}
						switch (choice) {
						case "1":/// show balance
							System.out.println("Bank Balance: " + servAccount.getAccount(acId).getBalance());
							System.out.println("Wallet Balance: " + servAccount.getAccount(acId).getWallet());
							break;

						case "2":// deposit to bank account

							System.out.print("Amount: ");

							amount = Double.parseDouble(sc.next());

							servAccount.deposit(amount,acId);
							System.out.println("Bank Balance: " + servAccount.getAccount(acId).getBalance());
							System.out.println("Wallet Balance: " + servAccount.getAccount(acId).getWallet());
							break;

						case "3":// transfer money form bank to wallet

							System.out.print("Amount: ");
							
									amount = Double.parseDouble(sc.next());
									
							servAccount.bankToWallet(amount,acId);
							break;

						case "4":// withdraw form wallet
							System.out.print("Enter Receiver Account Id: ");
							int receiverId = sc.nextInt();
							System.out.print("Amount: ");
							amount = Double.parseDouble(sc.next());
							servAccount.walletToWallet(amount,acId,receiverId);

							break;

						case "5":// transfer money back to bank

							System.out.print("Amount: ");
							
									amount = Double.parseDouble(sc.next());
									
							servAccount.walletToBank(amount,acId);

							break;
						case "6":// print transaction
							System.out.println(
									"\nCustomer_Id\tBalance\tWallet\tDate_of_Transaction\tDescription\n--------------------------------------------------------------------------");
							try {
								List<CSTransaction> tlist = servAccount.getTransactions(acId);
								tlist.stream().forEach(System.out::println);
							} catch (Exception e) {
								e.printStackTrace();
							}
							break;
						case "7":
							System.out.println("Logged out");
							flag = false;
							logoutFlag = true;
							break;
						default:
							System.out.println("Invalid Choice");
							flag = false;
							break;
						}

					}
				}

				else {
					System.out.println("Invalid Account Number or Password.");
				}
				break;

			case "3":
				Iterable<CSAccount> accounts =servAccount.getAll();

				accounts.forEach(System.out::println);
				break;

			case "4":
				sc.close();
				sc1.close();
				
				System.out.println("Thank You.");
				System.exit(0);
				break;

			default:
				System.out.println("Invalid Choice.");
				break;
			}
			System.out.print(
					"\n---------------------------------------------------------------\n1.CREATE ACCOUNT\t2.SIGN IN\t3.SHOW ALL\t4.EXIT"
							+ "\n---------------------------------------------------------------\n\nEnter the choice: ");
			choice = sc.next();
		}

	}

}
