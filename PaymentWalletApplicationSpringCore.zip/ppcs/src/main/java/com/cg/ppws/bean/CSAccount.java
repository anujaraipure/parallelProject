package com.cg.ppws.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CSAccount {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private String name;
	private String contact;
	private Date dateCreated;
	private Double Balance;
	private Double wallet;
	private String password;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Double getBalance() {
		return Balance;
	}
	public void setBalance(Double balance) {
		Balance = balance;
	}
	public Double getWallet() {
		return wallet;
	}
	public void setWallet(Double wallet) {
		this.wallet = wallet;
	}
	public CSAccount(int id, String name, String contact, Date dateCreated, Double balance, Double wallet,
			String password) {
		super();
		this.id = id;
		this.name = name;
		this.contact = contact;
		this.dateCreated = dateCreated;
		Balance = balance;
		this.wallet = wallet;
		this.password = password;
	}
	public CSAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CSAccount [id=" + id + ", name=" + name + ", contact=" + contact + ", dateCreated=" + dateCreated
				+ ", Balance=" + Balance + ", wallet=" + wallet + ", password=" + password + "]";
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
