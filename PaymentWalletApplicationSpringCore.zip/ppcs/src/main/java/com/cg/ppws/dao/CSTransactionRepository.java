package com.cg.ppws.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.ppws.bean.CSTransaction;

@Repository
public interface CSTransactionRepository extends CrudRepository<CSTransaction,Integer>{
	
	Iterable<CSTransaction> findAllByAccountId(int accountId);

}
