package com.capstore.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import javax.validation.ReportAsSingleViolation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.dao.BusinessAnalysisRepository;
import com.capstore.dao.CouponTableRepository;
import com.capstore.dao.MerchantTableRepository;
import com.capstore.dao.OrderCustomerRepository;
import com.capstore.dao.OrderProductRepository;
import com.capstore.dao.ProductRepository;
import com.capstore.model.BusinessAnalysis;
import com.capstore.model.CouponTable;
import com.capstore.model.MerchantTable;
import com.capstore.model.OrderCustomer;
import com.capstore.model.OrderProduct;
import com.capstore.model.Product;

@Service
public class BusinessAnalysisService {

	@Autowired
	CouponTableRepository couponRepo;

	@Autowired
	MerchantTableRepository merchantRepo;

	@Autowired
	OrderCustomerRepository orderCustomerRepo;

	@Autowired
	OrderProductRepository orderProductRepo;

	@Autowired
	ProductRepository productRepo;

	@Autowired
	BusinessAnalysisRepository businessAnalysisRepo;

	public void addToCouponRepo(List<CouponTable> coupon) {
		couponRepo.saveAll(coupon);
	}

	public void getAllCouponRepo() {
		couponRepo.findAll().forEach(n -> System.out.println(n));
	}

	public void addToMerchantRepo(List<MerchantTable> merchant) {
		merchantRepo.saveAll(merchant);
	}

	public void addToOrderCustomerRepo(List<OrderCustomer> orderCustomer) {
		orderCustomerRepo.saveAll(orderCustomer);
	}

	public void addToOrderProductRepo(List<OrderProduct> orderProduct) {
		orderProductRepo.saveAll(orderProduct);
	}

	public void addToProductRepo(List<Product> product) {

		productRepo.saveAll(product);
	}

	public Iterable<MerchantTable> getAllMerchantRepo() {
		// TODO Auto-generated method stub

		return merchantRepo.findAll(); // .forEach(n->System.out.println(n));
	}

	public Iterable<OrderProduct> getAllOrderProduct() {
		// TODO Auto-generated method stub
		return orderProductRepo.findAll();
	}

	public Iterable<BusinessAnalysis> getRealWork() {

		/*
		 * product id, merchant id, quantity sold, avg rating of product, avg rating of
		 * merchant, total revenue of product; Product OrderProduct OrderCustomer
		 * MerchantTable
		 */
		businessAnalysisRepo.deleteAll();
		Iterable<OrderProduct> orderedProducts = orderProductRepo.findAll();
		Iterable<Product> products = productRepo.findAll();

		BusinessAnalysis report;
		Integer productDispatchQuantity = 0;
		Double productRevenue = 0d;
		for (Product p : products) {
			System.out.println("FOUND PRODUCT");
			report = new BusinessAnalysis();
			report.setProductId(p.getProductId());
			report.setAvg_rating_of_product(p.getProduct_rating());
			MerchantTable merchant = merchantRepo.findById(p.getMerchantId()).get();
			report.setMerchantId(p.getMerchantId());
			report.setAvg_rating_of_merchant(merchant.getMerchantRating());
			report.setQuantity_sold(0);
			businessAnalysisRepo.save(report);
		}
		Iterable<BusinessAnalysis> reports = businessAnalysisRepo.findAll();
		for (BusinessAnalysis r : reports) {
			for (OrderProduct op : orderedProducts) {
				if (r.getProductId().equals(op.getProductId())) {
					// BusinessAnalysis b = new BusinessAnalysis();
					System.out.println("FOUND PRODUCT");
					r.setProductId(op.getProductId());
					Product product = productRepo.findById(op.getProductId()).get();
					r.setAvg_rating_of_product(product.getProduct_rating());
					r.setMerchantId(op.getMerchantId());
					MerchantTable merchant = merchantRepo.findById(product.getMerchantId()).get();
					r.setAvg_rating_of_merchant(merchant.getMerchantRating());
					productDispatchQuantity = op.getQuantity() + productDispatchQuantity;

					r.setQuantity_sold(productDispatchQuantity);
					productRevenue = productRepo.findById(op.getProductId()).get().getPricePerUnit()
							* productDispatchQuantity;
					productDispatchQuantity = 0;
					r.setTotal_revenue_of_product(productRevenue);
					businessAnalysisRepo.save(r);
					System.out.println("ADDED PRODUCT");
				}

			}
		}
		return businessAnalysisRepo.findAll();
	}

	public Iterable<BusinessAnalysis> getRealWorkWithTime(Date from, Date to) {

		/*
		 * product id, merchant id, quantity sold, avg rating of product, avg rating of
		 * merchant, total revenue of product; Product OrderProduct OrderCustomer
		 * MerchantTable
		 */
		businessAnalysisRepo.deleteAll();
		Iterable<OrderProduct> orderedProducts = orderProductRepo.findAll();
		Iterable<OrderCustomer> orderedCustomer = orderCustomerRepo.findAll();
		Iterable<Product> products = productRepo.findAll();
		BusinessAnalysis report;
		Integer productDispatchQuantity = 0;
		Double productRevenue = 0d;
			for (OrderProduct op : orderedProducts) {
				for (OrderCustomer oc : orderedCustomer) {
					if (oc.getOrderId().equals(op.getOrderId())) {
							if(oc.getOrderDate().compareTo(from)>=0&&oc.getOrderDate().compareTo(to)<=0) {
								report = new BusinessAnalysis();
							System.out.println("FOUND PRODUCT");
							report.setProductId(op.getProductId());
							Product product = productRepo.findById(op.getProductId()).get();
							report.setAvg_rating_of_product(product.getProduct_rating());
							report.setMerchantId(op.getMerchantId());
							MerchantTable merchant = merchantRepo.findById(product.getMerchantId()).get();
							report.setAvg_rating_of_merchant(merchant.getMerchantRating());
							productDispatchQuantity = op.getQuantity() + productDispatchQuantity;

							report.setQuantity_sold(productDispatchQuantity);
							productRevenue = productRepo.findById(op.getProductId()).get().getPricePerUnit()
									* productDispatchQuantity;
							productDispatchQuantity = 0;
							report.setTotal_revenue_of_product(productRevenue);
							businessAnalysisRepo.save(report);
							System.out.println("ADDED PRODUCT");
							}
						}
					}
			
		}
		return businessAnalysisRepo.findAll();
	}

	public Iterable<OrderCustomer> getAllOrderCustomerRepo() {
		// TODO Auto-generated method stub
		return orderCustomerRepo.findAll();
	}

	public Iterable<Product> getAllProductRepo() {
		// TODO Auto-generated method stub
		return productRepo.findAll();
	}
}
