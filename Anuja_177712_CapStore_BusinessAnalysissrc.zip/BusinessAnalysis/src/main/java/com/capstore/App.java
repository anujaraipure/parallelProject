package com.capstore;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.capstore.model.CouponTable;
import com.capstore.model.MerchantTable;
import com.capstore.model.OrderCustomer;
import com.capstore.model.OrderProduct;
import com.capstore.model.Product;
import com.capstore.service.BusinessAnalysisService;


@SpringBootApplication
@EnableJpaRepositories(basePackages="com.*")
@EntityScan(basePackages="com.*")
@ComponentScan(basePackages="com.*")
@EnableAutoConfiguration
public class App implements CommandLineRunner{

	public static void main(String[] args) {
		
		SpringApplication.run(App.class, args);
	}
	
	@Autowired
	BusinessAnalysisService service;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		/*service.addToCouponRepo(Arrays.asList(new CouponTable("1", Date.valueOf(LocalDate.now()), Date.valueOf(LocalDate.now()), "GOTOHELL", 20d, "valid", "abc", "abc"),
				new CouponTable("2", Date.valueOf(LocalDate.now()), Date.valueOf(LocalDate.now()), "IDONTCARE", 500d, "valid", "abc", "abc"),
				new CouponTable("3", Date.valueOf(LocalDate.now()), Date.valueOf(LocalDate.now()), "KILLYA", 30d, "valid", "abc", "abc"),
				new CouponTable("4", Date.valueOf(LocalDate.now()), Date.valueOf(LocalDate.now()), "GETLOST", 40d, "valid", "abc", "abc")
				));
		
		service.addToMerchantRepo(Arrays.asList(new MerchantTable("011", "8087864924", "ANUJA1", "Pune", 3, "k.r@r.com", 20d),
				new MerchantTable("012", "9309897729", "RITESH1", "Pune", 4, "r.r@u.com", 30d),
				new MerchantTable("013", "9011187406", "KALPANA1", "Pune", 5, "r.r@r.com", 30d),
				new MerchantTable("014", "8668851796", "RAMCHANDRA1", "Pune", 2, "a.r@r.com", 20d))
				);
		
		
		service.addToOrderCustomerRepo(Arrays.asList(new OrderCustomer("101", "1001", "delivered", Date.valueOf(LocalDate.now()), 5000d, 1),
				new OrderCustomer("102", "1002", "cancelled", Date.valueOf(LocalDate.now()), 600d, 2),
				new OrderCustomer("103", "1003", "in process", Date.valueOf(LocalDate.now()), 950d, 1),
				new OrderCustomer("104", "1004", "delivered", Date.valueOf(LocalDate.now()), 1200d, 3)));
		
		service.addToOrderProductRepo(Arrays.asList(new OrderProduct("101", "2101", "011", 5000d, 1, "IDONTCARE", 500d),
				new OrderProduct("102", "211", "013", 300d, 2, "", 0d),
				new OrderProduct("103", "341", "011", 950d, 1, "GETLOST", 40d),
				new OrderProduct("104", "301", "014", 500d, 2, "GOTOHELL", 20d),
				new OrderProduct("104", "111", "013", 200d, 1, "KILLYA", 30d)));
		
		service.addToProductRepo(Arrays.asList(new Product("2101", "Laptop Cover", "productDescription", 5500d, 20, "1", "011", "productImage", "productTnC",2),
				new Product("211", "DAcne Face Wash", "productDescription", 330d, 200, "7", "013", "productImage", "productTnC",3),
				new Product("241", "Episoft AC Sunscreen", "productDescription", 470d, 100, "7", "013", "productImage", "productTnC",4),
				new Product("341", "Earphone", "productDescription", 990d, 20, "1", "011", "productImage", "productTnC",1),
				new Product("301", "Ladies Top", "productDescription", 520d, 200, "1", "014", "productImage", "productTnC",2),
				new Product("111", "Earrings", "productDescription", 200d, 140, "1", "013", "productImage", "productTnC",5)));*/
	}

}
