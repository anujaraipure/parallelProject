package com.capstore.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstore.model.MerchantTable;

public interface MerchantTableRepository extends CrudRepository<MerchantTable,String> {

}
