package com.capstore.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstore.model.OrderProduct;

public interface OrderProductRepository extends CrudRepository<OrderProduct, String> {

}
