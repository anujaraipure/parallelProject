package com.capstore.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstore.model.CouponTable;

public interface CouponTableRepository extends CrudRepository<CouponTable,String> {

}
