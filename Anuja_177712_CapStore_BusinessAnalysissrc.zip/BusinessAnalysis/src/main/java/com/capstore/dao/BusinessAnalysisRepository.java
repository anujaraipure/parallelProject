package com.capstore.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstore.model.BusinessAnalysis;

public interface BusinessAnalysisRepository extends CrudRepository<BusinessAnalysis,Integer> {

}
