package com.capstore.dao;

import org.springframework.data.repository.CrudRepository;

import com.capstore.model.OrderCustomer;

public interface OrderCustomerRepository extends CrudRepository<OrderCustomer,String> {

}
