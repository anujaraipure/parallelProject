package com.capstore.model;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderProduct {
	/***
	 * 
	 * 1	order_id	reference ORDER_MASTER(order_id)	varchar2(10)
2	product_id	reference PRODUCTS(product_id)		varchar2(10)
3	merchant_id	reference MERCHANT(merchant_id)		varchar2(10)
4	price							double precision
5	quantity						number(3)
6	coupon_code	reference COUPON(coupon_code)		varchar2(10)
7	coupon_discount	reference COUPON(coupon_discount)	number(10)

	 */
	@Id
	private String orderId;
	private String productId;
	private String  merchantId;
	private Double price;
	private Integer quantity;
	private String couponCode;
	private Double couponDiscount;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public Double getCouponDiscount() {
		return couponDiscount;
	}
	public void setCouponDiscount(Double couponDiscount) {
		this.couponDiscount = couponDiscount;
	}
	public OrderProduct(String orderId, String productId, String merchantId, Double price, Integer quantity,
			String couponCode, Double couponDiscount) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.merchantId = merchantId;
		this.price = price;
		this.quantity = quantity;
		this.couponCode = couponCode;
		this.couponDiscount = couponDiscount;
	}
	public OrderProduct() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "OrderProduct [orderId=" + orderId + ", productId=" + productId + ", merchantId=" + merchantId
				+ ", price=" + price + ", quantity=" + quantity + ", couponCode=" + couponCode + ", couponDiscount="
				+ couponDiscount + "]";
	}
	
	
}
