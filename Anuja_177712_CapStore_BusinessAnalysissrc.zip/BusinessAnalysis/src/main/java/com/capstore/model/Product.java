package com.capstore.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {

	/**
	 * 
	 * 1 product_id varchar2(10) 2 product_name varchar2(30) 3 product_brand
	 * varchar2(30) 4 product_description varchar2(250) 5 product_per_unit_price
	 * Double Precision 6 product_quantity Integer 7 category_id Integer 8
	 * merchant_id varchar2(10) 9 product_image BLOB 10 product_tnc varchar2(50) 11
	 * product_rating Integer
	 */
	@Id
	private String productId;
	private String productName;
	private String productDescription;
	private Double pricePerUnit;
	private Integer quantity;
	private String categoryId;
	private String merchantId;
	private String productImage;
	private String productTnC;
	private Integer product_rating;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public Double getPricePerUnit() {
		return pricePerUnit;
	}

	public void setPricePerUnit(Double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public String getProductTnC() {
		return productTnC;
	}

	public void setProductTnC(String productTnC) {
		this.productTnC = productTnC;
	}

	public Product(String productId, String productName, String productDescription, Double pricePerUnit,
			Integer quantity, String categoryId, String merchantId, String productImage, String productTnC,
			Integer product_rating) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productDescription = productDescription;
		this.pricePerUnit = pricePerUnit;
		this.quantity = quantity;
		this.categoryId = categoryId;
		this.merchantId = merchantId;
		this.productImage = productImage;
		this.productTnC = productTnC;
		this.product_rating = product_rating;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productDescription="
				+ productDescription + ", pricePerUnit=" + pricePerUnit + ", quantity=" + quantity + ", categoryId="
				+ categoryId + ", merchantId=" + merchantId + ", productImage=" + productImage + ", productTnC="
				+ productTnC + ", product_rating=" + product_rating + "]";
	}

	public Integer getProduct_rating() {
		return product_rating;
	}

	public void setProduct_rating(Integer product_rating) {
		this.product_rating = product_rating;
	}

}
