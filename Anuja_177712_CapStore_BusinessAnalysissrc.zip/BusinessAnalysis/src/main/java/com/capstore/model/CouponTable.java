package com.capstore.model;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CouponTable {
	/**
	 * 
	 * 		COUPONTABLE

1	coupon_id	varchar2(10)	
2	coupon_date	varchar2(10)
3	coupon_validity	date
4	coupon_code	date
5	coupon_discount	double precision
6	coupon_status	varchar2(10)
7	coupon_type	varchar2(10)
8	discount_type	varchar2(10)

	 */
	@Id
	private String couponId;
	private Date couponDate;
	private Date couponValidity;
	private String couponCode;
	private Double couponDiscount;
	private String couponStatus;
	private String couponType;
	private String discountType;
	public String getCouponId() {
		return couponId;
	}
	public void setCouponId(String couponId) {
		this.couponId = couponId;
	}
	public Date getCouponDate() {
		return couponDate;
	}
	public void setCouponDate(Date couponDate) {
		this.couponDate = couponDate;
	}
	public Date getCouponValidity() {
		return couponValidity;
	}
	public void setCouponValidity(Date couponValidity) {
		this.couponValidity = couponValidity;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public Double getCouponDiscount() {
		return couponDiscount;
	}
	public void setCouponDiscount(Double couponDiscount) {
		this.couponDiscount = couponDiscount;
	}
	public String getCouponStatus() {
		return couponStatus;
	}
	public void setCouponStatus(String couponStatus) {
		this.couponStatus = couponStatus;
	}
	public String getCouponType() {
		return couponType;
	}
	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}
	public String getDiscountType() {
		return discountType;
	}
	public void setDiscountType(String discountType) {
		this.discountType = discountType;
	}
	public CouponTable(String couponId, Date couponDate, Date couponValidity, String couponCode, Double couponDiscount,
			String couponStatus, String couponType, String discountType) {
		super();
		this.couponId = couponId;
		this.couponDate = couponDate;
		this.couponValidity = couponValidity;
		this.couponCode = couponCode;
		this.couponDiscount = couponDiscount;
		this.couponStatus = couponStatus;
		this.couponType = couponType;
		this.discountType = discountType;
	}
	public CouponTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CouponTable [couponId=" + couponId + ", couponDate=" + couponDate + ", couponValidity=" + couponValidity
				+ ", couponCode=" + couponCode + ", couponDiscount=" + couponDiscount + ", couponStatus=" + couponStatus
				+ ", couponType=" + couponType + ", discountType=" + discountType + "]";
	}
	
	
}
