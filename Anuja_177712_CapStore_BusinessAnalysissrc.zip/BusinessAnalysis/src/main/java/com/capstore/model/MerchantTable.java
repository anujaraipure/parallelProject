package com.capstore.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MerchantTable {

	/**
	 * 
	 * 
1	merchant_id		varchar2(10)
2	merchant_mobile		varchar2(10)
3	merchant_name		varchar2(30)
4	billing_address		varchar2(50)
5	merchant_rating		number(1)
6	merchant_email		varchar2(30)
7	merchant_discount	double precision

	 */
	@Id
	private String merchantId;
	private String merchantMobile;
	private String merchantName;
	private String billingAddress;
	private Integer merchantRating;
	private String merchantEmail;
	private Double merchantDiscount;
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantMobile() {
		return merchantMobile;
	}
	public void setMerchantMobile(String merchantMobile) {
		this.merchantMobile = merchantMobile;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}
	public Integer getMerchantRating() {
		return merchantRating;
	}
	public void setMerchantRating(Integer merchantRating) {
		this.merchantRating = merchantRating;
	}
	public String getMerchantEmail() {
		return merchantEmail;
	}
	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}
	public Double getMerchantDiscount() {
		return merchantDiscount;
	}
	public void setMerchantDiscount(Double merchantDiscount) {
		this.merchantDiscount = merchantDiscount;
	}
	public MerchantTable(String merchantId, String merchantMobile, String merchantName, String billingAddress,
			Integer merchantRating, String merchantEmail, Double merchantDiscount) {
		super();
		this.merchantId = merchantId;
		this.merchantMobile = merchantMobile;
		this.merchantName = merchantName;
		this.billingAddress = billingAddress;
		this.merchantRating = merchantRating;
		this.merchantEmail = merchantEmail;
		this.merchantDiscount = merchantDiscount;
	}
	public MerchantTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "MerchantTable [merchantId=" + merchantId + ", merchantMobile=" + merchantMobile + ", merchantName="
				+ merchantName + ", billingAddress=" + billingAddress + ", merchantRating=" + merchantRating
				+ ", merchantEmail=" + merchantEmail + ", merchantDiscount=" + merchantDiscount + "]";
	}
	
}
