package com.capstore.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BusinessAnalysis {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer analysisID;
	private String productId, merchantId;
	private Integer quantity_sold, avg_rating_of_product, avg_rating_of_merchant;
	private double total_revenue_of_product;
	public Integer getAnalysisID() {
		return analysisID;
	}
	public void setAnalysisID(Integer analysisID) {
		this.analysisID = analysisID;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public Integer getQuantity_sold() {
		return quantity_sold;
	}
	public void setQuantity_sold(Integer quantity_sold) {
		this.quantity_sold = quantity_sold;
	}
	public Integer getAvg_rating_of_product() {
		return avg_rating_of_product;
	}
	public void setAvg_rating_of_product(Integer avg_rating_of_product) {
		this.avg_rating_of_product = avg_rating_of_product;
	}
	public Integer getAvg_rating_of_merchant() {
		return avg_rating_of_merchant;
	}
	public void setAvg_rating_of_merchant(Integer avg_rating_of_merchant) {
		this.avg_rating_of_merchant = avg_rating_of_merchant;
	}
	public double getTotal_revenue_of_product() {
		return total_revenue_of_product;
	}
	public void setTotal_revenue_of_product(double total_revenue_of_product) {
		this.total_revenue_of_product = total_revenue_of_product;
	}
	@Override
	public String toString() {
		return "AnalysisReport [analysisID=" + analysisID + ", productId=" + productId + ", merchantId=" + merchantId
				+ ", quantity_sold=" + quantity_sold + ", avg_rating_of_product=" + avg_rating_of_product
				+ ", avg_rating_of_merchant=" + avg_rating_of_merchant + ", total_revenue_of_product="
				+ total_revenue_of_product + "]";
	}
	public BusinessAnalysis(Integer analysisID, String productId, String merchantId, Integer quantity_sold,
			Integer avg_rating_of_product, Integer avg_rating_of_merchant, double total_revenue_of_product) {
		super();
		this.analysisID = analysisID;
		this.productId = productId;
		this.merchantId = merchantId;
		this.quantity_sold = quantity_sold;
		this.avg_rating_of_product = avg_rating_of_product;
		this.avg_rating_of_merchant = avg_rating_of_merchant;
		this.total_revenue_of_product = total_revenue_of_product;
	}
	public BusinessAnalysis() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
