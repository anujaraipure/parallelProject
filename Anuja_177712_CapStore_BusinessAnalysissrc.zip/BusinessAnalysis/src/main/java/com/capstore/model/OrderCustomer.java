package com.capstore.model;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderCustomer {
	/**
	 * 
1	order_id 	primary key				varchar2(10)
2	customer_id	references customer(customer_id)	varchar2(10)
3	order_status						varchar2(10)
4	order_date						Timestamp with time zone
5	total_amount						double precision
6	no_of_products						number(4)

	 * 
	 */
	@Id
	private String orderId;
	private String customerId;
	private String orderStatus;
	private Date orderDate;
	private Double totalAmount;
	private Integer noOfProducts;
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Integer getNoOfProducts() {
		return noOfProducts;
	}
	public void setNoOfProducts(Integer noOfProducts) {
		this.noOfProducts = noOfProducts;
	}
	public OrderCustomer(String orderId, String customerId, String orderStatus, Date orderDate, Double totalAmount,
			Integer noOfProducts) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.orderStatus = orderStatus;
		this.orderDate = orderDate;
		this.totalAmount = totalAmount;
		this.noOfProducts = noOfProducts;
	}
	public OrderCustomer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "OrderCustomer [orderId=" + orderId + ", customerId=" + customerId + ", orderStatus=" + orderStatus
				+ ", orderDate=" + orderDate + ", totalAmount=" + totalAmount + ", noOfProducts=" + noOfProducts + "]";
	}
	
	
	
}
