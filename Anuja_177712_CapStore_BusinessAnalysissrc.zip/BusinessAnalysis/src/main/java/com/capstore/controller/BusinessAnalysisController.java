package com.capstore.controller;


import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.model.BusinessAnalysis;
import com.capstore.model.MerchantTable;
import com.capstore.model.OrderCustomer;
import com.capstore.model.OrderProduct;
import com.capstore.model.Product;
import com.capstore.service.BusinessAnalysisService;

@RestController
public class BusinessAnalysisController {

	@Autowired 
	BusinessAnalysisService service;
	
	@GetMapping("/getMerchant/all")
	public Iterable<MerchantTable> showMerchants() {
		return service.getAllMerchantRepo();
	}
	
	@GetMapping("/getOrderProduct/all")
	public Iterable<OrderProduct> showOrderProduct() {
		return service.getAllOrderProduct();
	}
	
	@GetMapping("/getOrderCustomer/all")
	public Iterable<OrderCustomer> showOrderCustomer(){
		return service.getAllOrderCustomerRepo();
	}

	@GetMapping("/getProduct/all")
	public Iterable<Product> showProduct(){
		return service.getAllProductRepo();
	}
	
	@GetMapping("getAll")
	public String showAll(){
		return service.getAllProductRepo() +"\n"+ service.getAllOrderCustomerRepo()+"\n\n"+service.getAllOrderProduct()+"\n\n"+service.getAllMerchantRepo();
	}
	
	@GetMapping("/getAnalysis")
	public Iterable<BusinessAnalysis> showRealWork(){
		return service.getRealWork();
	}
	
	@GetMapping("/getAnalysis/{from}/{to}")
	public Iterable<BusinessAnalysis> showAnalysisTimePeriod(@PathVariable Date from,@PathVariable Date to){
		return service.getRealWorkWithTime(from,to);
	}
	
}		