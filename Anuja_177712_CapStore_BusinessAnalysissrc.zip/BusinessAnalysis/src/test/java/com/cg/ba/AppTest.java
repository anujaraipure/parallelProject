package com.cg.ba;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.java.en.Given;
import cucumber.api.junit.Cucumber;

/**
 * Unit test for simple App.
 */
@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\anraipur\\Desktop\\pseudoLP\\BusinessAnalysis\\src\\test\\java\\com\\cg\\feature\\BusinessAnalysis.feature", glue = "com.cg.stepdef", strict = true, plugin = {
		"pretty", "html:target/coachingform-report" }, monochrome = true)

public class AppTest {
	
}
