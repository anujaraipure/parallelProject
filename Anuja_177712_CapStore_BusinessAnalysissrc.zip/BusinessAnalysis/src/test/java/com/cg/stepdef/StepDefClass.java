package com.cg.stepdef;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefClass {

	WebDriver driver;

	@Given("^Analysis page is opened$")
	public void analysis_page_is_opened() throws Throwable {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\anraipur\\Desktop\\Module4\\JobsWorld\\src\\test\\java\\com\\cg\\jw\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:4200/");

	}

	@Given("^verify the title of page$")
	public void verify_the_title_of_page() throws Throwable {
		assertEquals("CapStoreProject",driver.getTitle());
		System.out.println(driver.getTitle());
	}

	@Given("^check the text shown$")
	public void check_the_text_shown() throws Throwable {
		assertEquals("Business Analysis",driver.findElement(By.tagName("h1")).getText());
		System.out.println(driver.findElement(By.tagName("h1")).getText());
	}
	
	@When("^fill data in date fields as \"([^\"]*)\" and \"([^\"]*)\"$")
	public void fill_data_in_date_fields_as_and(String arg1, String arg2) throws Throwable {
		driver.findElement(By.name("fromDate")).sendKeys(arg1);
		driver.findElement(By.name("toDate")).sendKeys(arg2);
		driver.findElement(By.name("generate")).click();
	}

	@Then("^accept alert$")
	public void accept_alert() throws Throwable {
		
		System.out.println("Alert:  "+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
	}

	@Then("^observe the data$")
	public void observe_the_data() throws Throwable {
		Thread.sleep(2000);
	}
	
	@After()
	public void closeAllDriver() {
		driver.close();
	}

}
