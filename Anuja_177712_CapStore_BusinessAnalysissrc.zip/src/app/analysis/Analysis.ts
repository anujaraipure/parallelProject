export interface Analysis{
    analysisID;
    productId;
    merchantId;
    quantity_sold;
    avg_rating_of_product;
    avg_rating_of_merchant;
    total_revenue_of_product;
}