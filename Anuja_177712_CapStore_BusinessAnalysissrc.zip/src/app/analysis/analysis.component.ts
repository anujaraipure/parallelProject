import { Component, OnInit, ViewChild } from '@angular/core';
import { AnalysisService } from '../analysis.service';
import { Analysis } from '../analysis/Analysis';
import { MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-analysis',
  templateUrl: './analysis.component.html',
  styleUrls: ['./analysis.component.css']
})
export class AnalysisComponent implements OnInit  {
  
  productId=[];
  quantitySold=[];

  chart=[];
  displayedColumns=['productId','merchantId','quantity_sold','avg_rating_of_product','avg_rating_of_merchant','total_revenue_of_product'];
 
  analysis:any[]=[];
  @ViewChild(MatSort) sort = MatSort;
  dataSource;
  constructor(private service:AnalysisService) { }

  ngOnInit() {
    this.service.getData().subscribe(data=>{
      if(!data){
        console.log("data not found");
        return;
      }
      this.dataSource=new MatTableDataSource(data);
      this.dataSource.sort= this.sort;
    });
    
    this.service.getData().subscribe(res=>{
                                      res.forEach(p=>this.productId.push(p.productId)),
                                     res.forEach(p=>  this.quantitySold.push(p.quantity_sold))});


                                     console.log(this.productId);
                                     console.log(this.quantitySold);
   
      
     this.chart=new Chart('canvas',{type: 'line',
              data:{
                        labels:this.quantitySold,
                        datasets:[
                          {
                            data:this.productId,
                            borderColor:'#3cba9f',
                            fill: false
                          },
                          {
                            data:this.productId,
                            borderColor:'#3cba9f',
                            fill: false
                          }
                        ]
               },
              options: {
                        legend: {
                        display: false
                        },
                       scales: {
                                xAxes: [{
                                  display: true
                                  }],
                                 yAxes: [{
                                  display: true
                                  }],
                               }
              }
              });
      
    console.log(this.chart);
  }
  fromDate:any;
  toDate:any;
  flag=false;

 

  getByDate(){
    
    
    if(this.fromDate==undefined||this.toDate==undefined){
      alert("Select date")
    }
    else{
          this.service.getDataByDate(this.fromDate,this.toDate).subscribe(data=>{
              if(!data){
                  console.log("data not found");
                  return;
              }
              this.dataSource=new MatTableDataSource(data);
              this.dataSource.sort= this.sort;
        });
    }
    
 }

}
