import { Injectable } from '@angular/core';
import {Http,Response,Headers, RequestOptions} from '@angular/http';
import { Analysis } from './analysis/Analysis';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AnalysisService {

  constructor(private http:HttpClient) {}

  url:string;
  analysis:any;

  getAnalysis():any{
    
    //return this.http.get(this.url).subscribe(data=>this.analysis=data.json());
  }

  getData():Observable<Analysis[]>{

  return this.http.get<Analysis[]>('http://localhost:8083/getAnalysis');
  }

  getDataByDate(from,to):Observable<Analysis[]>{
    
    return this.http.get<Analysis[]>("http://localhost:8083/getAnalysis/"+from+"/"+to);
   }
}