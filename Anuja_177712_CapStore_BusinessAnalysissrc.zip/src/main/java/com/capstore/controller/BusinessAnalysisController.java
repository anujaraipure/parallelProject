package com.capstore.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.capstore.model.DispatchAnalysis;
import com.capstore.service.BusinessAnalysisService;
import com.capstore.model.BusinessAnalysis;

@Controller
public class BusinessAnalysisController {


	@Autowired
	BusinessAnalysisService businessAnalysisService;

	//for getting sales analysis(category wise)
	@GetMapping("/salesAnalysis/{fromDate}/to/{toDate}")
	public ResponseEntity<List<BusinessAnalysis>> getSalesAnalysis(@PathVariable("fromDate") @DateTimeFormat(pattern="yyyy-MM-dd")
	Date fromDate, @PathVariable("toDate") @DateTimeFormat(pattern="yyyy-MM-dd") Date toDate)	{
		if(fromDate.before(toDate))	{
			List<BusinessAnalysis> salesAnalysis=businessAnalysisService.getSalesAnalysis(fromDate, toDate);
			
			if(salesAnalysis.isEmpty())
				return new ResponseEntity("Sorry! No business during this time period!", HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<BusinessAnalysis>>(salesAnalysis,HttpStatus.OK);
		}
		return new ResponseEntity("Sorry! No business during this time period!", HttpStatus.NOT_FOUND);
	}
	
	//for getting dispatch details(for analyzing merchants)
	@GetMapping("/dispatchAnalysis/{fromDate}/to/{toDate}")
	public ResponseEntity<List<DispatchAnalysis>> getDispatchAnalysis(@PathVariable("fromDate") @DateTimeFormat(pattern="yyyy-MM-dd")
	Date fromDate, @PathVariable("toDate") @DateTimeFormat(pattern="yyyy-MM-dd") Date toDate)	{
		if(fromDate.before(toDate))	{
			List<DispatchAnalysis> dispatchAnalysis=businessAnalysisService.getDispatchDetailsBetween(fromDate, toDate);
			
			if(dispatchAnalysis.isEmpty())
				return new ResponseEntity("Sorry! No business during this time period!", HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<DispatchAnalysis>>(dispatchAnalysis,HttpStatus.OK);
		}
		return new ResponseEntity("Sorry! No business during this time period!", HttpStatus.NOT_FOUND);
	}
	
	
	
}
