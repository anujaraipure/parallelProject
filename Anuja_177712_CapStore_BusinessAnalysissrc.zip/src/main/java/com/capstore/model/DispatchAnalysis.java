package com.capstore.model;

public class DispatchAnalysis {

}
