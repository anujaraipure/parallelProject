package com.cg.eis.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TRANSACTIONJPA")
public class TransactionJPA {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String transactionId;
	
	private double amount;
	private  double balance;
	private String custId;
	private Date date;
	private String operation;
	private double  walletBalance;
	
	

	
	/*public TransactionJPA(String custId, double balance, double walletBalance, Date date, String operation, double amount)  {
		super();
		this.balance = balance;
		this.walletBalance = walletBalance;
		this.amount = amount;
		this.custId = custId;
		this.operation = operation;
		this.date = date;
	}*/


	public String getTransactionId() {
		return transactionId;
	}


	public TransactionJPA(double amount, double balance, String custId, Date date,
			String operation, double walletBalance) {
		super();
		this.amount = amount;
		this.balance = balance;
		this.custId = custId;
		this.date = date;
		this.operation = operation;
		this.walletBalance = walletBalance;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public TransactionJPA() {}
	

	public double getWalletBalance() {
		return walletBalance;
	}


	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}


	public String getCustId() {
		return custId;
	}
	
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Date getDate() {
		return date;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String getOperation() {
		return operation;
	}
	
	public void setOperation(String operation) {
		this.operation = operation;
	}

	
	@Override
	public String toString() {
		return "TransactionJPA [transactionId=" + transactionId + ", amount=" + amount + ", balance=" + balance
				+ ", custId=" + custId + ", date=" + date + ", operation=" + operation + ", walletBalance="
				+ walletBalance + "]";
	}


	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
}
