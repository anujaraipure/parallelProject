package com.cg.eis.pl;

import java.util.Scanner;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

import com.cg.eis.bean.AccountJPA;
import com.cg.eis.bean.TransactionJPA;
import com.cg.eis.exception.PWAException;
import com.cg.eis.service.AccountService;

public class User{

	public static void main(String[] args) throws SQLException {
		
		
		
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		 boolean logoutFlag=false;
		 boolean validationFlag=false;
		AccountService serviceObj=new AccountService();
		String choice=null;
		System.out.print("\n---------------------------------------------------------------\n1.CREATE ACCOUNT\t2.SIGN IN\t3.SHOW ALL\t4.EXIT"+"\n---------------------------------------------------------------\n\nEnter the choice: ");
		choice=sc.next();
		String name = null,contact = null,password = null;
		Double amount = null;
		
		while(true) {
				
			
			switch (choice) {
				
				case "1":///create
					
					AccountJPA a=new AccountJPA();
					a.setAcId(String.valueOf(Math.round(Math.random()*10000)));
					
					System.out.print("Enter following details to open account \nName:");
					do {
						try {
						name=sc1.nextLine();
						validationFlag=serviceObj.validateName(name);
						
						}
						catch(PWAException e) {
							System.err.println(e);
						}
					}while(!validationFlag);
					a.setName(name);
					validationFlag=false;
					//
					
					
					System.out.print("Contact Number:");
					do {
						try {
							contact=sc.next();
							validationFlag=serviceObj.validateContact(contact);
						}
						catch(PWAException e) {
							System.err.println(e);
						}
					}while (!validationFlag);
					a.setContact(contact);
					validationFlag=false;
					
					
					System.out.print("Password: ");
					do {
						try {
							password=sc.next();
							validationFlag=serviceObj.validatePassword(password);
						}
						catch(PWAException e) {
							System.err.println(e);
						}
					}while (!validationFlag);
					a.setPassword(password);
					validationFlag=false;
					
					System.out.print("Amount: ");
					do {
						try {
							amount=Double.parseDouble(sc.next());
							validationFlag=serviceObj.validateAmount(amount);
						}
						catch(PWAException e) {
							System.err.println(e);
						}
						catch (Exception e) {
							System.err.println(e);
						}
					}while (!validationFlag);
					a.setBalance(amount);	
					a.setDateCreated(Date.valueOf(LocalDate.now()));
					validationFlag=false;
					
					serviceObj.create(a);
					
					
				break;
		
				case "2":
					logoutFlag=false;
					System.out.print("Account Number: ");
					String acId=sc.next();
					System.out.print("Password: ");
					String p=sc.next();
					boolean account=serviceObj.logIn(acId, p);
					
					if(account) {
						AccountJPA acc=serviceObj.getAccount(acId);
						System.out.println("\n\n-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-*\n\t\t\t\tWELCOME "+acc.getName());
						
						boolean flag=true;
						while(flag) {
							if(!logoutFlag) {
							System.out.println("------------------------------------MENU--------------------------------------\n1.Show Balance\t\t2.Deposit in bank account\t3.Add money to wallet\n4.Pay From wallet\t5.Transfer back from wallet\t6.Print Transaction\n7.Logout\n------------------------------------------------------------------------------\nEnter Your Choice: ");
							choice=sc.next();
							}
							switch (choice) {
								case "1":///show balance
									System.out.println("Bank Balance: "+serviceObj.showAccountBalance(acId));
									System.out.println("Wallet Balance: "+serviceObj.showWalletBalance(acId));
									break;
									
								case "2"://deposit to bank account
									
										System.out.print("Amount: ");
										do {
											try {
												amount=Double.parseDouble(sc.next());
												validationFlag=true;
											}
											catch(Exception e) {
												System.err.println(e);
											}
										}while (!validationFlag);
										validationFlag=false;
										serviceObj.depositToAccount(acId,amount);
										System.out.println("Bank Balance: "+serviceObj.showAccountBalance(acId));
										System.out.println("Wallet Balance: "+serviceObj.showWalletBalance(acId));
									break;
							
								case "3"://transfer money form bank to wallet
									
									System.out.print("Amount: ");
									do {
										try {
											amount=Double.parseDouble(sc.next());
											validationFlag=true;
										}
										catch(Exception e) {
											System.err.println(e);
										}
									}while (!validationFlag);
									validationFlag=false;
									serviceObj.bankToWallet(acId,amount);
										
									break;
									
								case "4"://withdraw form wallet
									System.out.print("Enter Receiver Account Id: ");
									String receiverId=sc.next();
									System.out.print("Amount: ");
									do {
										try {
											amount=Double.parseDouble(sc.next());
											validationFlag=true;
										}
										catch(Exception e) {
											System.err.println(e);
										}
									}while (!validationFlag);
									validationFlag=false;
									serviceObj.walletToWallet(acId, receiverId, amount);
										
									break;
							
								case "5"://transfer money back to bank
								
									System.out.print("Amount: ");
									do {
										try {
											amount=Double.parseDouble(sc.next());
											validationFlag=true;
										}
										catch(Exception e) {
											System.err.println(e);
										}
									}while (!validationFlag);
									validationFlag=false;
									serviceObj.walletToBank(acId,  amount);
									
								break;
								case "6"://print transaction
									System.out.println("\nCustomer_Id\tBalance\tWallet\tDate_of_Transaction\tDescription\n--------------------------------------------------------------------------");
									try {
										List<TransactionJPA>tlist=serviceObj.getTransactions(acId);
										tlist.stream().forEach(System.out::println);
									}
									catch(Exception e) {
										e.printStackTrace();
									}
									break;
								case "7":
									System.out.println("Logged out");
									flag=false;
									logoutFlag=true;
									break;
								default:
									System.out.println("Invalid Choice");
									flag=false;
								break;
							}

							}
						}
					
					else {
						System.out.println("Invalid Account Number or Password.");
					}
			break;
				
			case "3":
				List<AccountJPA> accounts=new ArrayList<AccountJPA>(serviceObj.show());
					
					for(AccountJPA o:accounts) {
						System.out.println(o);
					}
			break;
				
				
			case "4":
				sc.close();
				sc1.close();
				serviceObj.wrapup();
				System.out.println("Thank You.");
				System.exit(0);
			break;
			
			default :
				System.out.println("Invalid Choice.");
			break;
				}
			System.out.print("\n---------------------------------------------------------------\n1.CREATE ACCOUNT\t2.SIGN IN\t3.SHOW ALL\t4.EXIT"+"\n---------------------------------------------------------------\n\nEnter the choice: ");
			choice=sc.next();
			}
		
		}
	}	
