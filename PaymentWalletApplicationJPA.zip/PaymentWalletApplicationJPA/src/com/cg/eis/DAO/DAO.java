package com.cg.eis.DAO;

import java.sql.SQLException;
import java.util.*;

import com.cg.eis.bean.AccountJPA;
import com.cg.eis.bean.TransactionJPA;

public interface DAO {

	List<AccountJPA> accounts=new ArrayList<AccountJPA>();
	List<TransactionJPA> transactions=new ArrayList<TransactionJPA>();
	
	public double showAccountBalance(String acId) throws SQLException;
	public double showWalletBalance(String acId) throws SQLException;
	
	public String create(AccountJPA a) throws SQLException;
	public List<AccountJPA> show() throws SQLException;
	public AccountJPA getAccount(String acId) throws SQLException;
	
	
	public boolean logIn(String acId,String password) throws SQLException;
	public void depositToAccount(String acId, double amount) throws SQLException;
	public void bankToWallet(String acId, double amount) throws SQLException;
	public double walletToWallet(String acId, String receiverAcId, double amount) throws SQLException;
	public void walletToBank(String acId, double amount) throws SQLException;
	public List<TransactionJPA> getTransactions(String acId)throws Exception;
	public boolean isAccount(String acId) throws SQLException;
	public void updateTransaction(String acId,double amount, String operation) throws SQLException;
}
