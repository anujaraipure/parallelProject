/**
 * 
 */
package com.cg.eis.DAO.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.eis.DAO.AccountDAO;
import com.cg.eis.bean.Account;

/**
 * @author anraipur
 *
 */
public class AccountDAOTest {

	/**
	 * @throws java.lang.Exception
	 */
	AccountDAO dao=new AccountDAO();
	Account a;
	@Before
	public void setUp() throws Exception {
		
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#create(com.cg.eis.bean.Account)}.
	 * @throws SQLException 
	 */
	/*@Test
	public void testCreate() throws SQLException {
		a=new Account("200",1200,"Kalpana","9011187405","kalpana712",100);
		assertNotNull(dao.create(a));
	}*/

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#showAccountBalance(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testShowAccountBalance() throws SQLException {
		assertNotNull(dao.showAccountBalance("4550"));
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#showWalletBalance(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testShowWalletBalance() throws SQLException {
		assertNotNull(dao.showWalletBalance("4550"));
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#show()}.
	 * @throws SQLException 
	 */
	@Test
	public void testShow() throws SQLException {
		assertNotNull(dao.show());
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#depositToAccount(java.lang.String, double)}.
	 * @throws SQLException 
	 */
	@Test
	public void testDepositToAccount() throws SQLException {
		double bankBal=dao.showAccountBalance("4550");
		dao.depositToAccount("4550", 1200);
		assertNotEquals(bankBal, dao.showAccountBalance("4550"));
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#walletToWallet(java.lang.String, java.lang.String, double)}.
	 * @throws SQLException 
	 */
	@Test
	public void testWalletToWallet() throws SQLException {
		assertNotNull(dao.walletToWallet("4550","1979", 150));
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#bankToWallet(java.lang.String, double)}.
	 * @throws SQLException 
	 */
	@Test
	public void testBankToWallet() throws SQLException {
		double walletBal=dao.showWalletBalance("4550");
		dao.bankToWallet("4550", 20);
		assertNotEquals(walletBal,dao.showWalletBalance("4550"));
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#walletToBank(java.lang.String, double)}.
	 * @throws SQLException 
	 */
	@Test
	public void testWalletToBank() throws SQLException {
		double bankBal=dao.showAccountBalance("4550");
		dao.walletToBank("4550", 20);
		assertNotEquals(bankBal,dao.showAccountBalance("4550"));
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#getAccount(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetAccount() throws SQLException {
		assertNotNull(dao.getAccount("4550"));
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#isAccount(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testIsAccount() throws SQLException {

		assertFalse(dao.isAccount("1"));
		assertTrue(dao.isAccount("4550"));
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#getTransactions(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetTransactions() throws SQLException {
		/*List list=dao.getTransactions("1");
		assertEquals(null,list);
		*/
	}

	/**
	 * Test method for {@link com.cg.eis.DAO.AccountDAO#logIn(java.lang.String, java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testLogIn() throws SQLException {

		assertFalse(dao.logIn("4550", "12"));
		assertTrue(dao.logIn("4550", "123456"));
	}

}
