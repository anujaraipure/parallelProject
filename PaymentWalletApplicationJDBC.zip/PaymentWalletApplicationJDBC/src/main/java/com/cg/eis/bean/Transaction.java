package com.cg.eis.bean;

import java.sql.Date;

public class Transaction {

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	private double  balance, walletBalance, amount;
	private String custId, operation;
	private Date date;
	
	
	public Transaction(String custId, double balance, double walletBalance, Date date, String operation, double amount) {
		super();
		this.custId = custId;
		this.balance = balance;
		this.walletBalance = walletBalance;
		this.date = date;
		this.operation = operation;
		this.amount = amount;
	}
	
	public Transaction() {}
	

	public double getWalletBalance() {
		return walletBalance;
	}


	public void setWalletBalance(double walletBalance) {
		this.walletBalance = walletBalance;
	}


	public String getCustId() {
		return custId;
	}
	
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Date getDate() {
		return date;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String getOperation() {
		return operation;
	}
	
	public void setOperation(String operation) {
		this.operation = operation;
	}

	@Override
	public String toString() {
		return ""+ custId + "\t\t" + balance + "\t" + walletBalance + "\t"+ date + "\t\t" + operation + "\t\t" + amount + "\n";
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
}
