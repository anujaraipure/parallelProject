package com.cg.eis.DAO;

import java.sql.SQLException;
import java.util.*;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.Transaction;

public interface DAO {

	List<Account> accounts=new ArrayList<Account>();
	List<Transaction> transactions=new ArrayList<Transaction>();
	
	public double showAccountBalance(String acId) throws SQLException;
	public double showWalletBalance(String acId) throws SQLException;
	
	public String create(Account a) throws SQLException;
	public List<Account> show() throws SQLException;
	public Account getAccount(String acId) throws SQLException;
	
	
	public boolean logIn(String acId,String password) throws SQLException;
	public void depositToAccount(String acId, double amount) throws SQLException;
	public void bankToWallet(String acId, double amount) throws SQLException;
	public double walletToWallet(String acId, String receiverAcId, double amount) throws SQLException;
	public void walletToBank(String acId, double amount) throws SQLException;
	public List<Transaction> getTransactions(String acId)throws Exception;
	public boolean isAccount(String acId) throws SQLException;
	public void updateTransaction(String acId,double amount, String operation) throws SQLException;
}
