package com.cg.eis.datab;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GetConnection {
	public static Connection c=null;
	public GetConnection() {
		try {
		Class.forName("oracle.jdbc.OracleDriver");
		GetConnection.c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","India123");
		if(GetConnection.c!=null) {
			System.out.println("connected");
		}
		else {
			System.out.println("Unable to connect");
		}
		}
		catch( ClassNotFoundException| SQLException e) {
			System.out.println(e);
		}
	}

}