package com.cg.eis.DAO;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.eis.bean.Account;
import com.cg.eis.datab.GetConnection;
import com.cg.eis.exception.PWAException;
import com.cg.eis.service.AccountService;

public class TemporaryTest {

	public void TemporaryTestfunc() throws SQLException {

		
		System.out.println(new GetConnection());
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		 boolean validationFlag=false;
		AccountService serviceObj=new AccountService();
		String name = null,contact = null,password = null;
		Double amount = null;
		
		AccountDAO ac=new AccountDAO();
		System.out.println(ac.show());
		
		
		Account a=new Account();
		a.setAcId(String.valueOf(Math.round(Math.random()*10000)));
		
		System.out.print("Enter following details to open account \nName:");
		do {
			try {
			name=sc1.nextLine();
			validationFlag=serviceObj.validateName(name);
			
			}
			catch(PWAException e) {
				System.err.println(e);
			}
		}while(!validationFlag);
		a.setName(name);
		validationFlag=false;
		//
		
		
		System.out.print("Contact Number:");
		do {
			try {
				contact=sc.next();
				validationFlag=serviceObj.validateContact(contact);
			}
			catch(PWAException e) {
				System.err.println(e);
			}
		}while (!validationFlag);
		a.setContact(contact);
		validationFlag=false;
		
		
		System.out.print("Password: ");
		do {
			try {
				password=sc.next();
				validationFlag=serviceObj.validatePassword(password);
			}
			catch(PWAException e) {
				System.err.println(e);
			}
		}while (!validationFlag);
		a.setPassword(password);
		validationFlag=false;
		
		System.out.print("Amount: ");
		do {
			try {
				amount=Double.parseDouble(sc.next());
				validationFlag=serviceObj.validateAmount(amount);
			}
			catch(PWAException e) {
				System.err.println(e);
			}
			catch (Exception e) {
				System.err.println(e);
			}
		}while (!validationFlag);
		a.setBalance(amount);		
		validationFlag=false;
		a.setWallet(0d);
		a.setDateCreated(Date.valueOf(LocalDate.now()));
		ac.create(a);
		
	}

}
