package com.cg.eis.service;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import com.cg.eis.DAO.AccountDAO;
import com.cg.eis.bean.Account;
import com.cg.eis.bean.Transaction;
import com.cg.eis.exception.PWAException;

public class AccountService implements Service{

	AccountDAO dao=new AccountDAO();

	
	public void create(Account a) throws SQLException {
	
			dao.create(a);
	}

	public boolean logIn(String acId, String password) throws SQLException {
		
			return dao.logIn(acId,password);
	}
	
	public List<Account> show() throws SQLException {
		
		return dao.show();
	}

	public void walletToBank(String acId, double amount) throws SQLException {
		if(dao.isAccount(acId)) 
			dao.walletToBank(acId, amount);
	}
	
	public void depositToAccount(String acId, double amount) throws SQLException {
		
		boolean a=dao.isAccount(acId);
		if(a) 
			dao.depositToAccount(acId,amount);	
				
		else 
			System.out.println("Invalid Account Number.");
	}

	public void walletToWallet(String acId,String receiverId, double amount) throws SQLException {
		boolean a=dao.isAccount(acId);
		boolean receiver=dao.isAccount(receiverId);
		if(receiver) {
			if(a) {
				if(dao.showWalletBalance(acId)>amount) 
						System.out.println("Wallet Balance: "+dao.walletToWallet(acId,receiverId,amount));
					else 
						System.out.println("You dont have enough balance. \n(Deposit money into your wallet to perform this action)");
			}
			else 
				System.out.println("Incorrect Account ID.");
			}
		else System.out.println("Incorrect Receiver Account Number");
	}

	public void bankToWallet(String acId, double amount) throws SQLException {
		boolean a=dao.isAccount(acId);
		if(a) 
			if(dao.showAccountBalance(acId)<amount)
				System.out.println("You dont have enough balance.");
			else
				dao.bankToWallet(acId, amount);
	}


	public double showAccountBalance(String acId) throws SQLException {
		
		return dao.showAccountBalance(acId);
	}

	public Account getAccount(String acId) throws SQLException {
		
		return dao.getAccount(acId);
	}

	public double getWallet(String acId) throws SQLException {
		
		return dao.showWalletBalance(acId);
	}

	public List<Transaction> getTransactions(String acId) throws SQLException {
		
		return dao.getTransactions(acId);
	}

	public double showWalletBalance(String acId) throws SQLException {

		return dao.showWalletBalance(acId);
	}

	
	public boolean validateName(String name) throws PWAException {
		boolean valid=true;
		Pattern p=Pattern.compile("^[a-zA-Z ]*$");
		Matcher m=p.matcher(name);
		
			if(!m.matches()) {
				throw new PWAException("Name Should Contain Only Characters. (Reenter the name)");
			}
		return valid;
	}

	
	public boolean validateAmount(Double amount) throws PWAException {
		boolean valid=true;
		if(amount<1000) {
			throw new PWAException("Amount Should Be More 1000 or More. (Reenter amount)");
		}
		return valid;
	}


	public boolean validateContact(String contact) throws PWAException {
		boolean valid=true;
		Pattern p=Pattern.compile("[7-9]{1}[0-9]{9}");
		Matcher m=p.matcher(contact);


		if(!m.matches()) {
			throw new PWAException("Invalid Contact Number. (Reenter contact)");
		}
		return valid;
	}

	
	public boolean validatePassword(String password) throws PWAException {
		boolean valid=true;
		Pattern p=Pattern.compile("[0-9A-Za-z]{6,}");
		Matcher m=p.matcher(password);


		if(!m.matches()) {
			throw new PWAException("Invalid Password. (Reenter password with minimum length 6)");
		}
		return valid;
	}

	public void wrapup() throws SQLException {
		dao.wrapup();
	}

	
}
