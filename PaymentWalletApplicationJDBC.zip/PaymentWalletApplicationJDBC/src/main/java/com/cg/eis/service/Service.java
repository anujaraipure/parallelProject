package com.cg.eis.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.Transaction;
import com.cg.eis.exception.PWAException;

public interface Service {

	
	public double showAccountBalance(String acId) throws SQLException;
	public double showWalletBalance(String acId) throws SQLException;
	
	public List<Account> show() throws SQLException;
	public Account getAccount(String acId) throws SQLException;
	
	public void create(Account a) throws SQLException;
	public void depositToAccount(String acId, double amount) throws SQLException;
	public void walletToWallet(String acId,String receiverId, double amount) throws SQLException;
	public void bankToWallet(String acId, double amount) throws SQLException;
	public void walletToBank(String acId, double amount) throws SQLException;
	public List<Transaction> getTransactions(String acId)throws Exception;
	public double getWallet(String acId) throws SQLException;
	public boolean logIn(String acId, String password) throws SQLException;
	
	

}
