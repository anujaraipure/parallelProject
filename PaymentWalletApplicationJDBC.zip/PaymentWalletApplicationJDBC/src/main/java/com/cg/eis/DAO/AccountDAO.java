package com.cg.eis.DAO;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.Transaction;
import com.cg.eis.datab.GetConnection;

public class AccountDAO implements DAO {
	
	GetConnection conn=new GetConnection();


	/**
	 * To Create New Account In Database
	 */
	public String create(Account a) throws SQLException {
		
		PreparedStatement ps=conn.c.prepareStatement("insert into Account values(?,?,?,?,?,?,?)");
		ps.setString(1, a.getAcId());
		ps.setString(2, a.getName());
		ps.setString(3, a.getContact());
		ps.setString(4, a.getPassword());
		ps.setDouble(5, a.getBalance());
		ps.setDouble(6, a.getWallet());
		ps.setDate(7, a.getDateCreated());
		ps.executeQuery();
		
		/*Transaction t = new Transaction(a.getAcId(),a.getBalance(),a.getWallet(), Date.valueOf(LocalDate.now()),"Account Created",a.getBalance());
		transactions.add(t);*/
		
		updateTransaction(a.getAcId(),a.getBalance(),"Account Created");
		
		PreparedStatement ps1=conn.c.prepareStatement("Select acId from Account where acId=?");
		ps1.setString(1, a.getAcId());
		ResultSet rs=ps1.executeQuery();
		if(rs.next()) 
			return rs.getString(1);
		else
			return null;
	}

	
	/**
	 * To Show Balance from given account number
	 */
	/*public Account(String acId, double balance, String name, String contact, String password, double wallet)*/
	@Override
	public double showAccountBalance(String acId) throws SQLException {

		PreparedStatement ps=conn.c.prepareStatement("Select balance from Account where acId=?");
		ps.setString(1, acId);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			return rs.getDouble(1);
		else return -1;
	}


	/**
	 * To Show Wallet Balance from given account number
	 */
	@Override
	public double showWalletBalance(String acId) throws SQLException {
		PreparedStatement ps=conn.c.prepareStatement("Select wallet from Account where acId=?");
		ps.setString(1, acId);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			return rs.getDouble(1);
		return rs.getDouble(1);
	}

	/**
	 * To display all accounts in a List
	 */
	//public Account(String acId, double balance, String name, String contact, String password, double wallet)	@Override
	public List<Account> show() throws SQLException {
		PreparedStatement ps=conn.c.prepareStatement("Select * from Account");
		Account a;
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			a=new Account(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDouble(5),rs.getDouble(6),rs.getDate(7));
			accounts.add(a);
		}
		return accounts;
	}

	/**
	 * To add Money in bank account
	 */
	@Override
	public void depositToAccount(String acId, double amount) throws SQLException {
		PreparedStatement ps=conn.c.prepareStatement("update account set balance=balance+? where acId=?");
		
		
		
		
		ps.setDouble(1, amount);
		ps.setString(2, acId);
		ps.executeQuery();
	/*	
		Transaction t = new Transaction(a.getAcId(),a.getBalance(),a.getWallet(), Date.valueOf(LocalDate.now()),"Account Created",a.getBalance());
		transactions.add(t);*/
		updateTransaction(acId,amount,"Deposited");
		
	}

	/**
	 * To pay money from wallet
	 * @throws SQLException 
	 */
	@Override
	public double walletToWallet(String acId,String receiverAcId, double amount) throws SQLException {
		PreparedStatement ps=conn.c.prepareStatement("update account set wallet=wallet-? where acId=?");
		ps.setDouble(1, amount);
		ps.setString(2, acId);
		ps.executeQuery();
		
		updateTransaction(acId,amount,"Paid from wallet");
		ps=conn.c.prepareStatement("update account set wallet=wallet+? where acId=?");
		ps.setDouble(1, amount);
		ps.setString(2, receiverAcId);
		ps.executeQuery();
		
		updateTransaction(receiverAcId,amount,"Received in wallet");
		return showWalletBalance(acId);
	}

	/**
	 * To add Money in wallet from bank account
	 */
	@Override
	public void bankToWallet(String acId, double amount) throws SQLException {
		PreparedStatement ps=conn.c.prepareStatement("update account set balance=balance-? where acId=?");
		
		ps.setDouble(1, amount);
		ps.setString(2, acId);
		ps.executeQuery();
		
		
		ps=conn.c.prepareStatement("update account set wallet=wallet+? where acId=?");
		
		ps.setDouble(1, amount);
		ps.setString(2, acId);
		ps.executeQuery();
		updateTransaction(acId,amount,"Added to wallet");
	}

	/** 
	 * To transfer wallet money back to account
	 */
	public void walletToBank(String acId, double amount) throws SQLException {
		PreparedStatement ps=conn.c.prepareStatement("update account set balance=balance+? where acId=?");
		
		ps.setDouble(1, amount);
		ps.setString(2, acId);
		ps.executeQuery();
		
		
		ps=conn.c.prepareStatement("update account set wallet=wallet-? where acId=?");
		
		ps.setDouble(1, amount);
		ps.setString(2, acId);
		ps.executeQuery();
		
		updateTransaction(acId,amount,"Wallet to bank");
		
	}

	/**
	 * To get perticular account info
	 * 
	 * String acId, double balance, String name, String contact, String password, double wallet, Date dateCreated) 
	 */
	@Override
	public Account getAccount(String acId) throws SQLException {
		Account account=null;
		PreparedStatement ps=conn.c.prepareStatement("Select * from Account where acId=?");
		ps.setString(1, acId);
		ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			account=new Account(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDouble(5),rs.getDouble(6),rs.getDate(7));
		}
		return account;
	}
	
	
	

	

	@Override
	public boolean isAccount(String acId) throws SQLException {
		boolean isAccount=false;
		PreparedStatement ps=conn.c.prepareStatement("Select * from Account where acId=?");
		ps.setString(1, acId);
		ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			isAccount=true;
		}
		return isAccount;
	}
	
//	String custId, double balance, double walletBalance, Date date, String operation, double amount
	@Override
	public List<Transaction> getTransactions(String acId) throws SQLException {
		Transaction t;
		List<Transaction> listT=new ArrayList<Transaction>();
		PreparedStatement ps=conn.c.prepareStatement("Select * from transaction");
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()) {
			if(rs.getString(1).equals(acId)) {
			t=new Transaction(rs.getString(1), rs.getFloat(2), rs.getFloat(3), rs.getDate(5), rs.getString(6),  rs.getDouble(4));
			listT.add(t);
			}
		}
		//System.out.println(t);
		
		/*PreparedStatement ps=conn.c.prepareStatement("Select * from Account");
		Account a;
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			a=new Account(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDouble(5),rs.getDouble(6),rs.getDate(7));
			accounts.add(a);
		}
		return accounts;*/
		return listT;
	}


	@Override
	public boolean logIn(String acId, String password) throws SQLException {
		boolean login=false;
		PreparedStatement ps=conn.c.prepareStatement("Select * from Account where acId=? and password=?");
		ps.setString(1, acId);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			login=true;
		
		return login;
	}


	public void wrapup() throws SQLException {
		conn.c.close();
	}


	@Override
	public void updateTransaction(String acId, double amount, String operation) throws SQLException {
		Account a=null;
		PreparedStatement ps=conn.c.prepareStatement("Select * from Account where acId=?");
		ps.setString(1, acId);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			a=new Account(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getDouble(5),rs.getDouble(6),rs.getDate(7));
//		String custId, double balance, double walletBalance, Date date, String operation, double amount)
		Transaction t=new Transaction();
		
		t.setCustId(acId);
		t.setBalance(a.getBalance());
		t.setWalletBalance(a.getWallet());
		t.setAmount(amount);
		t.setDate(Date.valueOf(LocalDate.now()));
		t.setOperation(operation);
		
		
		ps=conn.c.prepareStatement("insert into transaction values(?,?,?,?,?,?)");
		ps.setString(1, t.getCustId());
		ps.setDouble(2, t.getBalance());
		ps.setDouble(3, t.getWalletBalance());
		ps.setDouble(4, amount);
		ps.setDate(5, t.getDate());
		ps.setString(6, operation);
		ps.executeQuery();
	}


	


	
}



/*	public Map<String,Account> show(){
*
		
		return accounts;
	}
	
	public int print(int n) {
		return n;
	}
	public double showAccountBalance(String acId) {
		Account account=getAccount(acId);
		
		return account.getBalance();
	}

	public double depositToAccount(Account account, double amount) {
		account.setBalance(account.getBalance()+amount);
		double bal=account.getBalance();
		Wallet wallet=getWallet(account.getAcId());
		Transaction t=new Transaction(account.getAcId(), account.getBalance(), wallet.getWalletBalance(),String.valueOf(LocalDate.now()), "Deposited to account"+amount);
		transactions.add(t);
		
		return bal;
	}
	
	public double withdrawFromWallet(Wallet wallet,Wallet receiverWallet, double amount) {
		double bal;
		wallet.setWalletBalance(wallet.getWalletBalance()-amount);
		receiverWallet.setWalletBalance(receiverWallet.getWalletBalance()+amount);
		bal=wallet.getWalletBalance();
		for(Account account:accounts.values()) {
			if(wallet.getAcId()==account.getAcId()) {
				Transaction t=new Transaction(account.getAcId(), account.getBalance(), wallet.getWalletBalance(),String.valueOf(LocalDate.now()), "Withdrawn form wallet "+amount);
				transactions.add(t);
				break;
			}
		}
		return bal;
	}

	
	public void depositToWallet(Account account,Wallet wallet, double amount) {
	
		account.setBalance(account.getBalance()-amount);
		wallet.setWalletBalance(wallet.getWalletBalance()+amount);
		System.out.println("Fund Transfer Completed Successfully!");
		System.out.println("Wallet Balance: "+wallet.getWalletBalance());
		Transaction t=new Transaction(account.getAcId(), account.getBalance(), wallet.getWalletBalance(),String.valueOf(LocalDate.now()), "Added to wallet "+amount);
		transactions.add(t);
		
	}
	
	public void printTrans(String acId)throws Exception {
		ObjectOutputStream out=new ObjectOutputStream(new  FileOutputStream("a"+acId+".txt"));
		for(Transaction transaction:transactions) {
			if(transaction.getCustId().equals(acId)) 
				System.out.println(transaction);
			out.writeObject(transaction);
		}
		
		
		out.close();
	}

	public Account getAccount(String acId) {
		Account account= accounts.get(acId);;
		return account;
	}


	public Transaction getTransaction(String acId) {
		Transaction transaction=null;
		for(Transaction i:transactions) {
			
			if(i.getCustId().equals(acId))
				System.out.println(i);
		}
		return transaction;
	}

	public Account logIn(String acId, String password) {
			if(accounts.get(acId)!=null) 
				if(accounts.get(acId).getPassword().equals(password)) {
					return accounts.get(acId);
					}
				
			return null;
	}

	public double showWalletBalance(String acId) {
		// TODO Auto-generated method stub
		Wallet wallet=getWallet(acId);
		return wallet.getWalletBalance();
	}

	@Override
	public double withdrawFromWallet(Account receiverAccountId, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void depositToWallet(Account account, double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Account getWallet(String acId) {
		// TODO Auto-generated method stub
		return null;
	}*/
	
